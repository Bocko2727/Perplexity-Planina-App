import type { GPXPoint } from "./types";
import { haversineMeters } from "./geo";

export interface ElevationProfileOptions {
  width?: number;
  height?: number;
  strokeColor?: string;
  fillColor?: string;
}

/**
 * Builds an inline SVG string plotting elevation (y) against cumulative distance (x).
 * Points without elevation data are skipped; if fewer than 2 remain, returns null.
 */
export function buildElevationProfileSVG(points: GPXPoint[], opts: ElevationProfileOptions = {}): string | null {
  const width = opts.width ?? 600;
  const height = opts.height ?? 140;
  const stroke = opts.strokeColor ?? "#0d7d4a";
  const fill = opts.fillColor ?? "rgba(13,125,74,0.15)";

  const withEle = points.filter((p) => p.ele !== null) as (GPXPoint & { ele: number })[];
  if (withEle.length < 2) return null;

  let cumDist = 0;
  const series: { d: number; e: number }[] = [{ d: 0, e: withEle[0].ele }];
  for (let i = 1; i < withEle.length; i++) {
    cumDist += haversineMeters(withEle[i - 1].lat, withEle[i - 1].lon, withEle[i].lat, withEle[i].lon);
    series.push({ d: cumDist, e: withEle[i].ele });
  }

  const maxD = series[series.length - 1].d || 1;
  const minE = Math.min(...series.map((s) => s.e));
  const maxE = Math.max(...series.map((s) => s.e));
  const eRange = maxE - minE || 1;

  const pad = 8;
  const toX = (d: number) => pad + (d / maxD) * (width - 2 * pad);
  const toY = (e: number) => height - pad - ((e - minE) / eRange) * (height - 2 * pad);

  const linePath = series.map((s, i) => `${i === 0 ? "M" : "L"}${toX(s.d).toFixed(1)},${toY(s.e).toFixed(1)}`).join(" ");
  const areaPath = `${linePath} L${toX(series[series.length - 1].d).toFixed(1)},${height - pad} L${toX(0).toFixed(1)},${height - pad} Z`;

  return (
    `<svg viewBox="0 0 ${width} ${height}" width="100%" height="${height}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Елевационен профил">` +
    `<path d="${areaPath}" fill="${fill}" stroke="none" />` +
    `<path d="${linePath}" fill="none" stroke="${stroke}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" />` +
    `</svg>`
  );
}
