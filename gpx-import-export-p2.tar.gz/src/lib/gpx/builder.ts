import type { GPXTrack } from "./types";

function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/** Parses loose "lat, lon" or "lat lon" strings (as stored in Hut.gps) into coordinates. */
export function parseGpsString(gps: string | null | undefined): { lat: number; lon: number } | null {
  if (!gps) return null;
  const match = gps.match(/(-?\d+\.\d+)\s*[,\s]\s*(-?\d+\.\d+)/);
  if (!match) return null;
  const lat = parseFloat(match[1]);
  const lon = parseFloat(match[2]);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  return { lat, lon };
}

interface WaypointInput {
  name: string;
  lat: number;
  lon: number;
  ele?: number | null;
  desc?: string;
}

const GPX_HEADER = (creator: string) =>
  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
  `<gpx version="1.1" creator="${escapeXml(creator)}" xmlns="http://www.topografix.com/GPX/1/1" ` +
  `xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ` +
  `xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd">\n`;

/** Builds a GPX document from a route's name + hut waypoints (best-effort, since routes don't store a full track line). */
export function buildGPXFromRoute(routeName: string, waypoints: WaypointInput[]): string {
  let xml = GPX_HEADER("ПЛАНИНА — planina.pplx.app");
  xml += `  <metadata><name>${escapeXml(routeName)}</name></metadata>\n`;
  for (const wp of waypoints) {
    xml += `  <wpt lat="${wp.lat}" lon="${wp.lon}">\n`;
    if (wp.ele !== null && wp.ele !== undefined) xml += `    <ele>${wp.ele}</ele>\n`;
    xml += `    <name>${escapeXml(wp.name)}</name>\n`;
    if (wp.desc) xml += `    <desc>${escapeXml(wp.desc)}</desc>\n`;
    xml += `  </wpt>\n`;
  }
  xml += `</gpx>\n`;
  return xml;
}

/** Builds a full GPX document (with a <trk> track) from a previously-imported GPXTrack, for re-export. */
export function buildGPXFromTrack(track: GPXTrack): string {
  let xml = GPX_HEADER("ПЛАНИНА — planina.pplx.app");
  xml += `  <trk>\n    <name>${escapeXml(track.name)}</name>\n    <trkseg>\n`;
  for (const p of track.points) {
    xml += `      <trkpt lat="${p.lat}" lon="${p.lon}">\n`;
    if (p.ele !== null) xml += `        <ele>${p.ele}</ele>\n`;
    if (p.time) xml += `        <time>${escapeXml(p.time)}</time>\n`;
    xml += `      </trkpt>\n`;
  }
  xml += `    </trkseg>\n  </trk>\n</gpx>\n`;
  return xml;
}

export function downloadGPX(filename: string, xml: string): void {
  const blob = new Blob([xml], { type: "application/gpx+xml" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".gpx") ? filename : `${filename}.gpx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
