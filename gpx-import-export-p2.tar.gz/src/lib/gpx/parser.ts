import type { GPXPoint, GPXTrack, ParsedGPX } from "./types";
import { computeStats } from "./geo";

export class GPXParseError extends Error {}

function textOf(el: Element | null | undefined): string | null {
  const t = el?.textContent?.trim();
  return t ? t : null;
}

/** Parses a GPX 1.1 (or 1.0) XML string into a single flattened track + stats. */
export function parseGPX(xml: string): ParsedGPX {
  let doc: Document;
  try {
    doc = new DOMParser().parseFromString(xml, "application/xml");
  } catch (e) {
    throw new GPXParseError("Файлът не може да бъде разчетен като XML.");
  }

  const parserError = doc.querySelector("parsererror");
  if (parserError) {
    throw new GPXParseError("Невалиден GPX/XML формат.");
  }

  const gpxEl = doc.querySelector("gpx");
  if (!gpxEl) {
    throw new GPXParseError("Файлът не съдържа валиден <gpx> елемент.");
  }

  // Collect points from all <trkpt> (tracks) or fall back to <rtept> (routes)
  let ptEls = Array.from(doc.querySelectorAll("trkpt"));
  if (ptEls.length === 0) ptEls = Array.from(doc.querySelectorAll("rtept"));
  if (ptEls.length === 0) {
    throw new GPXParseError("Файлът не съдържа track/route точки (trkpt/rtept).");
  }

  const points: GPXPoint[] = ptEls.map((pt) => {
    const lat = parseFloat(pt.getAttribute("lat") || "");
    const lon = parseFloat(pt.getAttribute("lon") || "");
    const eleText = textOf(pt.querySelector("ele"));
    const ele = eleText !== null ? parseFloat(eleText) : null;
    const time = textOf(pt.querySelector("time"));
    return { lat, lon, ele: ele !== null && !Number.isNaN(ele) ? ele : null, time };
  }).filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lon));

  if (points.length === 0) {
    throw new GPXParseError("Точките в GPX файла нямат валидни координати.");
  }

  const name =
    textOf(doc.querySelector("trk > name")) ||
    textOf(doc.querySelector("rte > name")) ||
    textOf(doc.querySelector("metadata > name")) ||
    "Импортиран маршрут";

  const track: GPXTrack = { name, points };
  const stats = computeStats(points);

  return { track, stats };
}

/** Reads a browser File object and parses it as GPX. */
export function parseGPXFile(file: File): Promise<ParsedGPX> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        resolve(parseGPX(String(reader.result || "")));
      } catch (e) {
        reject(e);
      }
    };
    reader.onerror = () => reject(new GPXParseError("Грешка при четене на файла."));
    reader.readAsText(file);
  });
}
