export interface GPXPoint {
  lat: number;
  lon: number;
  ele: number | null;
  time: string | null;
}

export interface GPXTrack {
  name: string;
  points: GPXPoint[];
}

export interface GPXStats {
  distanceKm: number;
  gainM: number;
  lossM: number;
  minEle: number | null;
  maxEle: number | null;
  bounds: { minLat: number; maxLat: number; minLon: number; maxLon: number } | null;
  pointCount: number;
}

export interface ParsedGPX {
  track: GPXTrack;
  stats: GPXStats;
}

export interface ImportedGPXRoute {
  id: string;
  name: string;
  importedAt: string;
  track: GPXTrack;
  stats: GPXStats;
  sourceRouteId?: string;
}
