import type { GPXPoint, GPXStats } from "./types";

const EARTH_RADIUS_M = 6371000;

/** Great-circle distance between two lat/lon points, in meters (Haversine formula). */
export function haversineMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_M * c;
}

/** Ignore elevation jitter smaller than this (meters) when accumulating gain/loss. */
const ELEVATION_NOISE_THRESHOLD_M = 1;

export function computeStats(points: GPXPoint[]): GPXStats {
  if (points.length === 0) {
    return { distanceKm: 0, gainM: 0, lossM: 0, minEle: null, maxEle: null, bounds: null, pointCount: 0 };
  }

  let distanceM = 0;
  let gainM = 0;
  let lossM = 0;
  let minEle: number | null = null;
  let maxEle: number | null = null;
  let minLat = points[0].lat, maxLat = points[0].lat;
  let minLon = points[0].lon, maxLon = points[0].lon;

  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    if (p.ele !== null) {
      minEle = minEle === null ? p.ele : Math.min(minEle, p.ele);
      maxEle = maxEle === null ? p.ele : Math.max(maxEle, p.ele);
    }
    minLat = Math.min(minLat, p.lat); maxLat = Math.max(maxLat, p.lat);
    minLon = Math.min(minLon, p.lon); maxLon = Math.max(maxLon, p.lon);

    if (i > 0) {
      const prev = points[i - 1];
      distanceM += haversineMeters(prev.lat, prev.lon, p.lat, p.lon);
      if (prev.ele !== null && p.ele !== null) {
        const delta = p.ele - prev.ele;
        if (delta > ELEVATION_NOISE_THRESHOLD_M) gainM += delta;
        else if (delta < -ELEVATION_NOISE_THRESHOLD_M) lossM += Math.abs(delta);
      }
    }
  }

  return {
    distanceKm: Math.round((distanceM / 1000) * 100) / 100,
    gainM: Math.round(gainM),
    lossM: Math.round(lossM),
    minEle: minEle !== null ? Math.round(minEle) : null,
    maxEle: maxEle !== null ? Math.round(maxEle) : null,
    bounds: { minLat, maxLat, minLon, maxLon },
    pointCount: points.length,
  };
}
