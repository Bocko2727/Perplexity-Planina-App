import { useRef, useState } from "react";
import { Upload, TriangleAlert, Check, Route, TrendingUp, TrendingDown, Ruler } from "lucide-react";

import { ModalShell } from "../ui/ModalShell";
import { parseGPXFile, GPXParseError } from "../../lib/gpx/parser";
import { buildElevationProfileSVG } from "../../lib/gpx/elevationProfile";
import { saveGPXRoute } from "../../services/gpxService";
import type { ParsedGPX } from "../../lib/gpx/types";

/* =========================================================================
   GPXImportModal — upload a .gpx file, preview stats + elevation profile, save
   ========================================================================= */
export function GPXImportModal({ onClose, onImported }: { onClose: () => void; onImported: (id: string) => void }) {
  const [fileName, setFileName] = useState<string>("");
  const [parsed, setParsed] = useState<ParsedGPX | null>(null);
  const [error, setError] = useState<string>("");
  const [saved, setSaved] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    setError("");
    setParsed(null);
    setSaved(false);
    setFileName(file.name);
    if (!file.name.toLowerCase().endsWith(".gpx")) {
      setError("Моля, избери файл с разширение .gpx");
      return;
    }
    try {
      const result = await parseGPXFile(file);
      setParsed(result);
    } catch (e) {
      setError(e instanceof GPXParseError ? e.message : "Неочаквана грешка при обработка на файла.");
    }
  };

  const handleSave = () => {
    if (!parsed) return;
    const entry = saveGPXRoute(parsed);
    setSaved(true);
    onImported(entry.id);
  };

  const svg = parsed ? buildElevationProfileSVG(parsed.track.points) : null;

  return (
    <ModalShell onClose={onClose} title="Импорт на GPX трак">
      <div className="space-y-4">
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            const f = e.dataTransfer.files?.[0];
            if (f) handleFile(f);
          }}
          className="border-2 border-dashed border-stone-300 rounded-xl p-6 text-center cursor-pointer hover:border-emerald-400 hover:bg-emerald-50/40 transition-colors"
        >
          <Upload size={28} className="mx-auto mb-2 text-stone-400" />
          <p className="text-sm text-stone-600">
            {fileName ? <span className="font-medium">{fileName}</span> : "Кликни или пусни .gpx файл тук"}
          </p>
          <input
            ref={inputRef}
            type="file"
            accept=".gpx,application/gpx+xml"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
            }}
          />
        </div>

        {error && (
          <div className="flex items-start gap-2 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg p-3 text-sm">
            <TriangleAlert size={16} className="shrink-0 mt-0.5" /> {error}
          </div>
        )}

        {parsed && (
          <div className="bg-white border border-stone-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center gap-2 font-bold text-stone-800">
              <Route size={16} className="text-emerald-700" /> {parsed.track.name}
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-stone-50 rounded-lg p-2">
                <Ruler size={14} className="mx-auto text-stone-500 mb-1" />
                <div className="text-sm font-bold">{parsed.stats.distanceKm} км</div>
                <div className="text-[10px] text-stone-500">Разстояние</div>
              </div>
              <div className="bg-stone-50 rounded-lg p-2">
                <TrendingUp size={14} className="mx-auto text-emerald-600 mb-1" />
                <div className="text-sm font-bold">+{parsed.stats.gainM} м</div>
                <div className="text-[10px] text-stone-500">Изкачване</div>
              </div>
              <div className="bg-stone-50 rounded-lg p-2">
                <TrendingDown size={14} className="mx-auto text-rose-600 mb-1" />
                <div className="text-sm font-bold">-{parsed.stats.lossM} м</div>
                <div className="text-[10px] text-stone-500">Слизане</div>
              </div>
            </div>
            <div className="text-[11px] text-stone-500">
              {parsed.stats.pointCount} точки
              {parsed.stats.minEle !== null && parsed.stats.maxEle !== null &&
                ` · Надм. височина ${parsed.stats.minEle}–${parsed.stats.maxEle} м`}
            </div>
            {svg ? (
              <div className="border border-stone-100 rounded-lg overflow-hidden bg-stone-50" dangerouslySetInnerHTML={{ __html: svg }} />
            ) : (
              <div className="text-[11px] text-stone-400 italic">Няма данни за височина в този файл — профилът не може да се начертае.</div>
            )}

            <button
              onClick={handleSave}
              disabled={saved}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-700 text-white text-sm font-bold hover:bg-emerald-800 disabled:opacity-60 disabled:cursor-not-allowed transition-colors"
            >
              {saved ? <Check size={16} /> : <Upload size={16} />} {saved ? "Записано!" : "Запази трака"}
            </button>
          </div>
        )}
      </div>
    </ModalShell>
  );
}
