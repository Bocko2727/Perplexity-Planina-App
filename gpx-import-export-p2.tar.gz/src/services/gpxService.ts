import type { ImportedGPXRoute, ParsedGPX } from "../lib/gpx/types";

const STORAGE_KEY = "planana-gpx-tracks";

export function loadGPXRoutes(): ImportedGPXRoute[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed = JSON.parse(raw || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function persist(routes: ImportedGPXRoute[]): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(routes));
  } catch {
    /* storage unavailable (private mode / quota) — track stays in memory only */
  }
}

export function saveGPXRoute(parsed: ParsedGPX, sourceRouteId?: string): ImportedGPXRoute {
  const entry: ImportedGPXRoute = {
    id: `gpx-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: parsed.track.name,
    importedAt: new Date().toISOString(),
    track: parsed.track,
    stats: parsed.stats,
    sourceRouteId,
  };
  const routes = loadGPXRoutes();
  routes.push(entry);
  persist(routes);
  return entry;
}

export function deleteGPXRoute(id: string): void {
  persist(loadGPXRoutes().filter((r) => r.id !== id));
}
